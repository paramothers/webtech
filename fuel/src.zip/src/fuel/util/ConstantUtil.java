
package fuel.util;

public class ConstantUtil {

    public static final String OUTPUT_FILE = "final_Fuel_Cost.txt";
}