package fuel.io;
import java.io.File;
import java.io.*;
import fuel.domain.*;
public class FuelCalculationFileWriter {
	
	 public void saveFuelCost(FuelCostCalculationParams fuelCostCalculationParams, String fileName) {
		// first create file object for file placed at location 
	    // specified by filepath 
	    File file = new File(fileName); 
	    try { 

			// create FileWriter object with file as parameter 
			FileWriter finalFuelCostFile = null;

			//add header only time.
			if(!file.exists()){				
				// adding header to csv 
				String header = "TOTAL_COST";
				finalFuelCostFile = new FileWriter(file);
				finalFuelCostFile.write(header); 
				finalFuelCostFile.append("\n");
			}else {

				finalFuelCostFile = new FileWriter(file);
			}
	        
	        double totalFuelCost = fuelCostCalculationParams.getTotalFuelCost();
	        String data1 = Double.toString(totalFuelCost);
	        System.out.println(" total fuel cost :"+data1);
			finalFuelCostFile.append(data1); 
			finalFuelCostFile.append("\n");
			finalFuelCostFile.flush();
			
	        finalFuelCostFile.close();
	    } catch (IOException e) { 
	        // TODO Auto-generated catch block 
	        e.printStackTrace(); 
	    } 
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
                           
	}

}
