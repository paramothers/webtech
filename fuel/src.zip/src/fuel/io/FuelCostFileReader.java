package fuel.io;

import java.io.File;  
import java.io.IOException; 
import java.io.FileReader;
import fuel.domain.*;


public class FuelCostFileReader {
	
	public void getFuelCostPerLiter(FuelCostCalculationParams fuelCostCalculationParams){
       File myfile = new File("Fuelcost.txt");
       try {
              FileReader costPerLiterFile = new FileReader(myfile);
              StringBuffer fuelCostPerLiter = new StringBuffer();
              int content;
              while ((content = costPerLiterFile.read()) != -1) {
                fuelCostPerLiter.append((char) content);
              }
              double costPerLiter = Double.parseDouble(fuelCostPerLiter.toString());
              System.out.println("fuel cost perliter:"+costPerLiter);
              fuelCostCalculationParams.setCostPerlitter(costPerLiter);
              costPerLiterFile.close();
           }catch (IOException e){
        	   
                e.printStackTrace();
            }
  }
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
                           
	}

}


